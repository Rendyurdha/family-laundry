-- Data contoh, jalankan sekali pada database pengujian.
INSERT INTO layanan (nama_layanan,kategori,harga,estimasi_hari,deskripsi) VALUES
('Cuci Setrika','kiloan',8000,3,'Harga per kilogram'),
('Cuci Express','kiloan',15000,1,'Harga per kilogram'),
('Laundry Sepatu','satuan',35000,3,'Harga per pasang');
