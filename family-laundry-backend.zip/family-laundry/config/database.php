<?php
return ['host'=>'127.0.0.1','port'=>3306,'name'=>'db_family_laundry','username'=>'root','password'=>''];
