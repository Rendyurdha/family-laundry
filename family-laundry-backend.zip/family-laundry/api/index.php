<?php
require __DIR__.'/../src/bootstrap.php';
try {
 $route=$_GET['route']??'health';$method=$_SERVER['REQUEST_METHOD'];
 if($route==='health'&&$method==='GET'){query('SELECT 1');respond(['success'=>true,'message'=>'API dan database terhubung.']);}
 if($route==='login'&&$method==='POST'){
  $a=body();$username=textField($a,'username',50);$password=textField($a,'password',255);
  $u=query('SELECT * FROM users WHERE username=?',[$username])->fetch();
  if(!$u||!password_verify($password,$u['password']))fail('Username atau password salah.',401);
  session_regenerate_id(true);unset($u['password']);$_SESSION['user']=$u;$_SESSION['csrf']=bin2hex(random_bytes(32));respond(['success'=>true,'data'=>$u,'csrf_token'=>$_SESSION['csrf']]);
 }
 if($route==='me'&&$method==='GET'){respond(['success'=>true,'data'=>auth(),'csrf_token'=>$_SESSION['csrf']]);}
 if($route==='logout'&&$method==='POST'){auth();$_SESSION=[];session_destroy();respond(['success'=>true]);}
 if($route==='layanan'&&$method==='GET'){respond(['success'=>true,'data'=>query('SELECT * FROM layanan ORDER BY id')->fetchAll()]);}
 if($route==='tracking'&&$method==='GET'){
  $code=textField($_GET,'kode',50);$o=query('SELECT kode_pesanan,tanggal_masuk,estimasi_selesai,status_cucian,status_pembayaran FROM pesanan WHERE kode_pesanan=?',[$code])->fetch();if(!$o)fail('Pesanan tidak ditemukan.',404);respond(['success'=>true,'data'=>$o]);
 }
 $u=auth();
 if($route==='layanan'&&$method==='POST'){
  auth(true);$a=body();$name=textField($a,'nama_layanan',100);$category=$a['kategori']??'';if(!in_array($category,['kiloan','satuan'],true))fail('kategori harus kiloan atau satuan.');$price=scaled($a['harga']??null,'harga',9999999999);$days=positiveInt($a['estimasi_hari']??null,'estimasi_hari');if($days>365)fail('estimasi_hari maksimal 365.');$desc=textField($a,'deskripsi',2000,false);query('INSERT INTO layanan (nama_layanan,kategori,harga,estimasi_hari,deskripsi) VALUES (?,?,?,?,?)',[$name,$category,money($price),$days,$desc]);respond(['success'=>true,'data'=>['id'=>(int)db()->lastInsertId()]],201);
 }
 if($route==='pelanggan'&&$method==='GET'){respond(['success'=>true,'data'=>query('SELECT * FROM pelanggan ORDER BY id DESC LIMIT 100')->fetchAll()]);}
 if($route==='pesanan'&&$method==='GET'){
  if(isset($_GET['id']))respond(['success'=>true,'data'=>orderData(positiveInt($_GET['id'],'id'))]);
  respond(['success'=>true,'data'=>query('SELECT p.*,c.nama FROM pesanan p JOIN pelanggan c ON c.id=p.pelanggan_id ORDER BY p.id DESC LIMIT 100')->fetchAll()]);
 }
 if($route==='pesanan'&&$method==='POST'){
  $a=body();$c=$a['pelanggan']??null;if(!is_array($c))fail('pelanggan harus objek.');$name=textField($c,'nama',100);$phone=textField($c,'nomor_telepon',15);if(!preg_match('/^\+?[0-9]{8,14}$/D',$phone))fail('nomor_telepon harus 8–14 digit, boleh diawali +.');$address=textField($c,'alamat',2000,false);
  $items=$a['detail']??null;if(!is_array($items)||!array_is_list($items)||count($items)<1||count($items)>50)fail('detail harus array berisi 1–50 layanan.');
  db()->beginTransaction();$total=0;$days=0;$details=[];$seen=[];
  foreach($items as $item){if(!is_array($item))fail('Setiap detail harus objek.');$id=positiveInt($item['layanan_id']??null,'layanan_id');if(isset($seen[$id]))fail('Layanan yang sama cukup satu baris.');$seen[$id]=true;
   $l=query('SELECT * FROM layanan WHERE id=? FOR UPDATE',[$id])->fetch();if(!$l)fail('Layanan tidak ditemukan.');$qty=scaled($item['berat_atau_jumlah']??null,'berat_atau_jumlah',99999);if($l['kategori']==='satuan'&&$qty%100!==0)fail('Jumlah layanan satuan harus bulat.');$price=scaled($l['harga'],'harga',9999999999);$sub=intdiv($price*$qty+50,100);$total+=$sub;if($total>9999999999)fail('Total biaya melebihi kapasitas database.');$days=max($days,(int)$l['estimasi_hari']);$details[]=[$id,money($qty),money($sub)];
  }
  query('INSERT INTO pelanggan (nama,nomor_telepon,alamat) VALUES (?,?,?)',[$name,$phone,$address]);$customer=(int)db()->lastInsertId();$code='FL-'.strtoupper(bin2hex(random_bytes(16)));$estimate=(new DateTimeImmutable())->modify("+$days days")->format('Y-m-d H:i:s');$now=date('Y-m-d H:i:s');
  query('INSERT INTO pesanan (kode_pesanan,pelanggan_id,user_id,tanggal_masuk,estimasi_selesai,total_biaya) VALUES (?,?,?,?,?,?)',[$code,$customer,$u['id'],$now,$estimate,money($total)]);$id=(int)db()->lastInsertId();foreach($details as $d)query('INSERT INTO detail_pesanan (pesanan_id,layanan_id,berat_atau_jumlah,subtotal) VALUES (?,?,?,?)',array_merge([$id],$d));db()->commit();respond(['success'=>true,'data'=>orderData($id)],201);
 }
 if($route==='status'&&$method==='PATCH'){
  $a=body();$id=positiveInt($a['pesanan_id']??null,'pesanan_id');$next=$a['status_cucian']??'';db()->beginTransaction();$o=query('SELECT * FROM pesanan WHERE id=? FOR UPDATE',[$id])->fetch();if(!$o)fail('Pesanan tidak ditemukan.',404);$steps=['diterima'=>'diproses','diproses'=>'selesai','selesai'=>'diambil'];if(($steps[$o['status_cucian']]??null)!==$next)fail('Status harus berurutan: diterima → diproses → selesai → diambil.');if($next==='diambil'&&$o['status_pembayaran']!=='lunas')fail('Pesanan harus lunas sebelum diambil.');query('UPDATE pesanan SET status_cucian=? WHERE id=?',[$next,$id]);db()->commit();respond(['success'=>true,'data'=>orderData($id)]);
 }
 if($route==='pembayaran'&&$method==='POST'){
  $a=body();$id=positiveInt($a['pesanan_id']??null,'pesanan_id');$amount=scaled($a['jumlah_bayar']??null,'jumlah_bayar',9999999999);$payment=$a['metode_pembayaran']??'';if(!in_array($payment,['tunai','transfer'],true))fail('Metode harus tunai atau transfer.');db()->beginTransaction();$o=query('SELECT * FROM pesanan WHERE id=? FOR UPDATE',[$id])->fetch();if(!$o)fail('Pesanan tidak ditemukan.',404);$paid=query('SELECT COALESCE(SUM(jumlah_bayar),0) FROM pembayaran WHERE pesanan_id=?',[$id])->fetchColumn();$paidCents=(int)round((float)$paid*100);$total=scaled($o['total_biaya'],'total_biaya',9999999999);if($amount>$total-$paidCents)fail('Pembayaran melebihi sisa tagihan.');query('INSERT INTO pembayaran (pesanan_id,tanggal_bayar,jumlah_bayar,metode_pembayaran,user_id) VALUES (?,?,?,?,?)',[$id,date('Y-m-d H:i:s'),money($amount),$payment,$u['id']]);$status=$paidCents+$amount===$total?'lunas':'belum_lunas';query('UPDATE pesanan SET status_pembayaran=? WHERE id=?',[$status,$id]);db()->commit();respond(['success'=>true,'data'=>orderData($id)],201);
 }
 if($route==='struk'&&$method==='GET')respond(['success'=>true,'data'=>orderData(positiveInt($_GET['id']??null,'id'))]);
 fail('Endpoint atau metode tidak tersedia.',404);
} catch(Throwable $e){try{if(db()->inTransaction())db()->rollBack();}catch(Throwable $ignored){}error_log((string)$e);respond(['success'=>false,'message'=>'Kesalahan server. Periksa koneksi database dan log Apache.'],500);}
