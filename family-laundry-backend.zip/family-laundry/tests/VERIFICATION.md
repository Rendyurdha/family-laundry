# Verifikasi paket

Lulus pemeriksaan sintaks semua file PHP menggunakan parser Tree-sitter PHP, struktur paket, validitas JSON koleksi Postman (13 request), header CSRF pada request perubahan data, keberadaan seluruh route yang didokumentasikan, dan kesamaan byte schema.sql dengan SQL asli.

Lingkungan pembuat paket tidak memiliki PHP/MySQL. Eksekusi PHP, koneksi PDO, impor SQL, dan pengujian transaksi/integrasi belum dijalankan. Jalankan koleksi Postman pada XAMPP dan uji kasus negatif yang tercantum di README sebelum menggunakan aplikasi.
