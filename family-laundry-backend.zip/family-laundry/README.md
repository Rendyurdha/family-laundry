# Family Laundry — Backend PHP 8.1+

API PHP native + PDO MySQL, sesuai enam tabel SQL yang diberikan. Tidak membutuhkan Composer atau frontend. Paket tahap pertama ini untuk pencatatan laundry oleh petugas dan tracking pelanggan tanpa akun.

## 1. Jalankan di XAMPP Windows

1. Ekstrak folder `family-laundry` ke `C:\xampp\htdocs\family-laundry`.
2. XAMPP Control Panel: Start Apache dan MySQL.
3. Buka `http://localhost/phpmyadmin`, buat database `db_family_laundry`, pilih database itu, lalu Import `database/schema.sql`. SQL asli tidak berisi CREATE DATABASE sehingga database harus dibuat dahulu.
4. Import `database/seed-layanan.sql` sekali untuk data layanan contoh. Jangan jalankan berulang karena akan menambah data duplikat.
5. Sesuaikan `config/database.php` dengan koneksi MySQL lokal. Bawaan: host 127.0.0.1, port 3306, user root, password kosong. Ini konfigurasi lokal XAMPP.
6. Buka terminal di folder proyek dan jalankan:

```powershell
C:\xampp\php\php.exe tools\create-user.php admin "Pemilik Laundry" pemilik "GantiPassword123!"
```

Gunakan passwordmu sendiri. Password tersimpan sebagai hash. Script menambah akun baru dan tidak menimpa akun lama. Jika username sudah ada, pilih username lain.

7. Buka `http://localhost/family-laundry/api/index.php?route=health`. Hasil sukses menyatakan API dan database terhubung.

## 2. Tes tanpa frontend dengan Postman

Import `Family-Laundry.postman_collection.json`. Jalankan request berurutan. Postman menyimpan cookie sesi otomatis; jangan berganti localhost ke 127.0.0.1 di tengah pengujian. Login otomatis menyimpan csrf_token pada variabel koleksi. Sesuaikan username/password request Login dengan akun yang dibuat.

| Route | Metode | Akses | Fungsi |
|---|---|---|---|
| health | GET | Publik | Cek API dan database |
| login | POST | Publik | Login petugas/pemilik |
| me | GET | Petugas | Akun sesi saat ini |
| logout | POST | Petugas + CSRF | Keluar |
| layanan | GET | Publik | Daftar layanan |
| layanan | POST | Pemilik + CSRF | Tambah layanan |
| pelanggan | GET | Petugas | 100 pelanggan terakhir |
| pesanan | POST | Petugas + CSRF | Buat pelanggan, pesanan, detail |
| pesanan | GET | Petugas | 100 pesanan terakhir |
| pesanan&id=1 | GET | Petugas | Detail pesanan |
| status | PATCH | Petugas + CSRF | Ubah status berurutan |
| pembayaran | POST | Petugas + CSRF | Catat pembayaran |
| struk&id=1 | GET | Petugas | Data struk dalam JSON |
| tracking&kode=FL-... | GET | Publik | Status tanpa identitas pelanggan |

Semua route menggunakan `api/index.php?route=...`. Untuk POST/PATCH gunakan `Content-Type: application/json`, serta `X-CSRF-Token` dari login kecuali pada request login. Token CSRF berbeda dari kode pelacakan pesanan.

### Contoh buat pesanan

```json
{
  "pelanggan": {
    "nama": "Rendy",
    "nomor_telepon": "081234567890",
    "alamat": "Jl. Mawar No. 10"
  },
  "detail": [
    {"layanan_id": 1, "berat_atau_jumlah": "2.50"},
    {"layanan_id": 3, "berat_atau_jumlah": "1"}
  ]
}
```

Jika seed baru dipasang, total contoh adalah Rp55.000 (2,5 × 8.000 + 1 × 35.000). API mengambil harga dari database; frontend tidak mengirim total atau subtotal. Gunakan ID aktual hasil GET layanan. Kiloan menerima maksimal 999,99 kg dengan dua angka desimal; satuan harus bulat. Estimasi selesai memakai estimasi_hari terlama di antara layanan. Nama pelanggan baru disimpan per transaksi; pencocokan pelanggan berulang belum dibuat karena nomor telepon tidak unik pada skema.

### Pembayaran

```json
{"pesanan_id": 1, "jumlah_bayar": "55000", "metode_pembayaran": "tunai"}
```

Bisa mencicil; status lunas otomatis ketika akumulasi pembayaran sama dengan total. Pembayaran nol, negatif, atau lebih besar dari sisa tagihan ditolak. Request pembayaran belum memakai idempotency key: periksa daftar pembayaran sebelum mengulang request setelah timeout.

### Status

```json
{"pesanan_id": 1, "status_cucian": "diproses"}
```

Urutan wajib: diterima → diproses → selesai → diambil. Untuk diambil harus lunas.

### Uji kesalahan

- Akses pesanan tanpa sesi → 401.
- POST dengan JSON rusak → 400 (setelah autentikasi bila route dilindungi).
- POST tanpa CSRF setelah login → 403.
- Layanan tidak ditemukan / jumlah tidak valid → 422, tidak ada pesanan tersimpan.
- Pesanan tidak ditemukan → 404.
- Pembayaran melebihi tagihan → 422, pembayaran tidak tersimpan.
- Loncat status atau ambil sebelum lunas → 422.
- Setelah logout, akses pesanan → 401.

## 3. Kesepakatan dengan frontend dan database

Koleksi Postman dan contoh respons API dapat menjadi kontrak awal. Frontend membaca data dari key `data`; error berisi `success: false` dan `message`. Angka DECIMAL dikembalikan sebagai string untuk mempertahankan nilai uang. Data struk JSON dapat dipakai frontend untuk tampilan cetak; paket ini belum menghasilkan PDF/HTML struk.

Skema asli tidak diubah. `pesanan.user_id` wajib dan `berat_atau_jumlah` wajib, sehingga saat ini petugas mencatat cucian yang sudah diterima/ditimbang. Pelanggan hanya melihat layanan dan tracking tanpa login. Belum ada reservasi online, jadwal pickup, catatan, penugasan kurir, atau status menunggu penjemputan. Untuk itu sepakati tabel reservasi terpisah dengan teman database; jangan isi user_id petugas secara sembarang dari frontend.

API menggunakan sesi pada origin yang sama. Saat frontend selesai, sajikan frontend dan API melalui origin yang sama atau konfigurasi proxy development. CORS lintas origin belum diaktifkan.

## 4. Batasan tahap pertama

Belum ada edit/hapus layanan/pelanggan, laporan, reset password, integrasi WhatsApp/QRIS, pembatalan, refund, pagination lengkap, maupun idempotensi pembayaran. FK asli memakai ON DELETE CASCADE; jangan menghapus layanan, pelanggan, atau petugas yang terhubung transaksi karena histori dapat ikut terhapus. API ini sengaja tidak menyediakan endpoint hapus.

Untuk penggunaan publik, tambahkan HTTPS, pembatasan percobaan login/tracking, pengelolaan secret, backup, serta akun database khusus aplikasi. Jangan unggah seluruh folder ini ke server publik tanpa konfigurasi perlindungan folder; `.htaccess` melindungi config/src/database/tools pada Apache yang mengizinkan aturan tersebut. Server PHP built-in tidak memproses `.htaccess`.

## 5. Verifikasi

Lihat `tests/VERIFICATION.md` untuk hasil pemeriksaan yang benar-benar dilakukan. Jalankan kembali koleksi Postman di XAMPP milikmu sebelum menghubungkan frontend.
