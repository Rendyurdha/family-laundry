<?php
header('Content-Type: application/json; charset=utf-8');
echo json_encode(['message'=>'Family Laundry API','health'=>'api/index.php?route=health','documentation'=>'Baca README.md pada paket unduhan.']);
