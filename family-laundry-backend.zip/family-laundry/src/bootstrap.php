<?php
 declare(strict_types=1);
 date_default_timezone_set('Asia/Jakarta');
 ini_set('display_errors','0');
 header('Content-Type: application/json; charset=utf-8');
 header('Cache-Control: no-store');
 session_set_cookie_params(['httponly'=>true,'samesite'=>'Lax','secure'=>!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off']);
 session_start();
 function respond($data,int $status=200): void { http_response_code($status); echo json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit; }
 function fail(string $message,int $status=422): void { respond(['success'=>false,'message'=>$message],$status); }
 function db(): PDO { static $pdo; if(!$pdo){$c=require __DIR__.'/../config/database.php';$pdo=new PDO("mysql:host={$c['host']};port={$c['port']};dbname={$c['name']};charset=utf8mb4",$c['username'],$c['password'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false]);} return $pdo; }
 function query(string $sql,array $args=[]): PDOStatement {$s=db()->prepare($sql);$s->execute($args);return $s;}
 function body(): array { $raw=file_get_contents('php://input');try{$a=json_decode($raw,true,512,JSON_THROW_ON_ERROR);}catch(JsonException $e){fail('Body harus JSON yang valid.',400);}if(!is_array($a)||array_is_list($a))fail('Body harus objek JSON.',400);return $a; }
 function textField(array $a,string $key,int $max,bool $required=true): string {$v=$a[$key]??'';if(!is_string($v))fail("$key harus teks.");$v=trim($v);if(($required&&$v==='')||preg_match_all('/./us',$v)>$max)fail("$key wajib diisi dan maksimal $max karakter.");return $v;}
 function positiveInt($v,string $key): int {if(filter_var($v,FILTER_VALIDATE_INT)===false || (int)$v<1)fail("$key harus bilangan bulat positif.");return (int)$v;}
 function scaled($v,string $key,int $max): int {if(!is_string($v)&&!is_int($v)&&!is_float($v))fail("$key harus angka.");$s=(string)$v;if(!preg_match('/^\d+(?:\.\d{1,2})?$/D',$s))fail("$key maksimal dua angka desimal.");$p=explode('.',$s);$n=(int)$p[0]*100+(int)str_pad($p[1]??'',2,'0');if($n<1||$n>$max)fail("$key di luar batas.");return $n;}
 function money(int $n): string {return sprintf('%d.%02d',intdiv($n,100),$n%100);}
 function auth(bool $owner=false): array {$u=$_SESSION['user']??null;if(!$u)fail('Silakan login sebagai petugas.',401);if($owner&&$u['role']!=='pemilik')fail('Hanya pemilik yang boleh melakukan ini.',403);if($_SERVER['REQUEST_METHOD']!=='GET'&&!hash_equals($_SESSION['csrf']??'',$_SERVER['HTTP_X_CSRF_TOKEN']??''))fail('X-CSRF-Token tidak valid.',403);return $u;}
 function orderData(int $id): array {$o=query('SELECT p.*, c.nama, c.nomor_telepon, c.alamat, u.nama AS nama_petugas FROM pesanan p JOIN pelanggan c ON c.id=p.pelanggan_id JOIN users u ON u.id=p.user_id WHERE p.id=?',[$id])->fetch();if(!$o)fail('Pesanan tidak ditemukan.',404);$o['detail']=query('SELECT d.*, l.nama_layanan,l.kategori FROM detail_pesanan d JOIN layanan l ON l.id=d.layanan_id WHERE d.pesanan_id=?',[$id])->fetchAll();$o['pembayaran']=query('SELECT id,tanggal_bayar,jumlah_bayar,metode_pembayaran FROM pembayaran WHERE pesanan_id=?',[$id])->fetchAll();return $o;}
