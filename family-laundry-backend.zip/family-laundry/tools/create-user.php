<?php
// Jalankan lewat terminal, bukan browser.
if(PHP_SAPI!=='cli'){http_response_code(404);exit;}
if($argc!==5){exit("Penggunaan: php tools/create-user.php username nama role password\n");}
[, $username,$nama,$role,$password]=$argv;
if(!in_array($role,['pemilik','petugas'],true)||strlen($password)<10||strlen($username)>50||strlen($nama)>100){exit("Role pemilik/petugas, password minimal 10 karakter, username maks 50, nama maks 100.\n");}
$c=require __DIR__.'/../config/database.php';
$p=new PDO("mysql:host={$c['host']};port={$c['port']};dbname={$c['name']};charset=utf8mb4",$c['username'],$c['password'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
$s=$p->prepare('INSERT INTO users (nama,username,password,role) VALUES (?,?,?,?)');$s->execute([$nama,$username,password_hash($password,PASSWORD_DEFAULT),$role]);echo "Petugas berhasil dibuat.\n";
